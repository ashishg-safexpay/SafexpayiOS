//
//  UniversalFrameworks.h
//  UniversalFrameworks
//
//  Created by Yash Jadhav on 05/08/21.
//

#import <Foundation/Foundation.h>

//! Project version number for UniversalFrameworks.
FOUNDATION_EXPORT double UniversalFrameworksVersionNumber;

//! Project version string for UniversalFrameworks.
FOUNDATION_EXPORT const unsigned char UniversalFrameworksVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UniversalFrameworks/PublicHeader.h>


