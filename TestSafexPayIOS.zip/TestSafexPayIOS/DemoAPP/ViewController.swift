//
//  ViewController.swift
//  DemoAPP
//
//  Created by Yash Jadhav on 04/08/21.
//

import UIKit
import TestSafexPayIOS

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("running")
    }

    @IBAction func btn_clicke(_ sender: UIButton)
    {
        print("Clicked on Button")
        SafexPaySwift.sharedInstance.showPaymentGateway(on: self, price: "123", orderId: "123", currency: "INR", txnType: "self", channel: "self", countryCode: "IND", aggregator: "paygate", successUrl: "https://www.safexpay.com/success", failureUrl: "https://www.safexpay.com/failure")
    }
    
}

