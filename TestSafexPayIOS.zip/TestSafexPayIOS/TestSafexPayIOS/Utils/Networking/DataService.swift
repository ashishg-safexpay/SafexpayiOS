//
//  DataService.swift
//  SafexPay
//
//  Created by Sandeep on 11/09/20.
//  Copyright © 2020 Antino Labs. All rights reserved.
//

import Foundation
import Alamofire

class DataService {

    private init() {}
    static var instance = DataService()
    
    //User Defaults Reference
    let defaults = UserDefaults.standard

    func getRequest(url:String, header:HTTPHeaders?,completion: @escaping (_ status:Bool, _ data:Any?)->()) {
        AF.request(url, method: .get, encoding: JSONEncoding.default, headers: header).responseString { response in
            if response.response?.statusCode == 200 {
                completion(true,response.value)
            }else{
                completion(false,nil)
            }
        }
    }
    
    func getRequestDictnry(url:String, header:HTTPHeaders?,completion: @escaping (_ sataus:Bool,_ data:NSDictionary?)->()) {
         AF.request(url, method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { response in
            if let responseJson = response.value as? NSDictionary {
                if let errorDetails = responseJson.value(forKey: "error_details") as? NSDictionary {
                    if errorDetails.value(forKey: "error_code") as? String == "1" {
                        completion(true,responseJson)
                    }else {
                        completion(false,nil)
                    }
                }
            } else {
                completion(false,nil)
            }
        }
     }

    func postRequest(url:String, postParam: [String : Any], header:HTTPHeaders?,completion: @escaping (_ sataus:Bool,_ data:NSDictionary?)->()) {
        AF.request(url, method: .post, parameters: postParam, encoding: JSONEncoding.default, headers: header).responseJSON { response in
            switch(response.result) {
            case .success(_):
                if response.response?.statusCode == 200 {
                    if let data = response.value as? NSDictionary{
                        completion(true,data)
                    }else{
                        completion(false,nil)
                    }
                }else{
                    completion(false,nil)
                }
            case .failure(let error):
                print(error)
                completion(false,nil)
            }
            
        }
    }
    
    func postRequestString(url:String, postParam: [String : Any], header:HTTPHeaders?,completion: @escaping (_ sataus:Bool,_ data:Any?)->()) {
        AF.request(url, method: .post, parameters: postParam, encoding: JSONEncoding.default, headers: header).responseString { response in
            if response.response?.statusCode == 200 {
                completion(true,response.value)
            }else{
                completion(false,nil)
            }
        }
    }
    
    func getRequestNative<T: Codable>(url: String, completion: @escaping (_ sataus: Bool, Swift.Result<T, Error>) -> ())
    {
        let sessions = URLSession.shared
        let mainURL = URL(string: url)
        
        let task = sessions.dataTask(with: mainURL!) { data, response, error in
            
            if let err = error
            {
                completion(false,.failure(err))
                print(err.localizedDescription)
                return
            }
            
            guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode) else
            {
                print("Server Error ")
                completion(false,.failure(response as! Error))
                return
            }
            
            guard let data = data else
            {
                return
            }
            
            let decoder = JSONDecoder()
            do {
                let finalValue = try decoder.decode(T.self, from: data)
                completion(true,.success(finalValue))
            }
            catch let errors {
                completion(false,.failure(errors))
            }
        }
        task.resume()
    }
    
    
    func postRequestNative(url: String, postParams: [String: Any], completion: @escaping (_ sataus:Bool,_ data:NSDictionary?) -> ())
    {
        let sessions = URLSession.shared
        let mainurl = URL(string: url)
        
        var request = URLRequest(url: mainurl!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = postParams.percentEscaped().data(using: .utf8)
        
        let task = sessions.dataTask(with: request) { data, response, error in
            
            if let err = error
            {
                completion(false,nil)
                print(err.localizedDescription)
                return
            }
            
            guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode) else
            {
                print("Server Error ")
                completion(false,nil)
                return
            }
            
            guard let data = data else
            {
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                print(json)
                completion(true, json as? NSDictionary)
            } catch {
                print("JSON error: \(error.localizedDescription)")
                completion(false, nil)
            }
            
//            let decoder = JSONDecoder()
//            do {
//                let finalValue = try decoder.decode(T.self, from: data)
//                completion(true,.success(finalValue))
//            }
//            catch let errors {
//                completion(false,.failure(errors))
//            }
        }
        task.resume()
    }
}

extension Dictionary {
    func percentEscaped() -> String {
        return map { (key, value) in
            let escapedKey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            let escapedValue = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            return escapedKey + "=" + escapedValue
        }
        .joined(separator: "&")
    }
}

extension CharacterSet {
    static let urlQueryValueAllowed: CharacterSet = {
        let generalDelimitersToEncode = ":#[]@" // does not include "?" or "/" due to RFC 3986 - Section 3.4
        let subDelimitersToEncode = "!$&'()*+,;="

        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimitersToEncode)")
        return allowed
    }()
}
