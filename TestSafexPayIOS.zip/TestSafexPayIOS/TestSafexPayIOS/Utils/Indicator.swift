//
//  Indicator.swift
//  SafexPay
//
//  Created by Yash Jadhav on 26/07/21.
//  Copyright © 2021 Antino Labs. All rights reserved.
//

import Foundation
import UIKit

//class Indicator
//{
//    // MARK: - Variables
//        private var containerView = UIView()
//        private var progressView = UIView()
//        private var activityIndicator = UIActivityIndicatorView()
//
//        static var shared = Indicator()
//
//        // To close for instantiation
//        private init() {}
//
//        // MARK: - Functions
//         func startAnimating(view: UIView) {
//            containerView.center = view.center
//            containerView.frame = view.frame
//            containerView.backgroundColor = UIColor(white: 0xffffff, alpha: 0.5)
//
//            progressView.frame = CGRect(x: 0, y: 0, width: 80, height: 80)
//            progressView.center = containerView.center
//            progressView.backgroundColor = UIColor(white: 0x444444, alpha: 0.7)
//            progressView.clipsToBounds = true
//
//            activityIndicator.frame = CGRect(x: 0, y: 0, width: 60, height: 60)
//            activityIndicator.center = CGPoint(x: progressView.bounds.width/2, y: progressView.bounds.height/2)
//
//            activityIndicator.style = .whiteLarge
//
//            view.addSubview(containerView)
//            containerView.addSubview(progressView)
//            progressView.addSubview(activityIndicator)
//
//            activityIndicator.startAnimating()
//        }
//
//        /// animate UIActivityIndicationView without blocking UI
//        func startSmoothAnimation(view: UIView) {
//            activityIndicator.frame = CGRect(x: 0, y: 0, width: 60, height: 60)
//            activityIndicator.center = view.center
//            activityIndicator.style = .whiteLarge
//            activityIndicator.color = UIColor.gray
//            view.addSubview(activityIndicator)
//            activityIndicator.startAnimating()
//        }
//
//        func stopAnimatimating() {
//            activityIndicator.stopAnimating()
//            containerView.removeFromSuperview()
//        }
//}

//  /// ActivityIndicator
//  let loader = UIActivityIndicatorView()
//
//  /// Shared Instance
//  static let shared: Indicator = {
//    let instance = Indicator()
//    return instance
//  }()
//
//  override init(frame: CGRect) {
//    super.init(frame: frame)
//    prepared()
//  }
//
//  required init?(coder aDecoder: NSCoder) {
//    fatalError("init(coder:) has not been implemented")
//  }
//
//  /// Design Indicator and Adding subView to Window
//  func prepared() {
//
//    self.backgroundColor = UIColor.white.withAlphaComponent(0.5)
//    self.frame = (UIApplication.shared.windows.first?.frame)!
//
//    loader.frame = (UIApplication.shared.windows.first?.frame)!
//    loader.style = .whiteLarge
//    loader.center = self.center
//    loader.color = UIColor.themeBlue
//    self.addSubview(loader)
//
//  }
//
//  /// Show Indicator View with animation
//  func show() {
//    let application = UIApplication.shared.delegate
//    // application.window?.rootViewController?.view.addSubview(self)
//
//    application.window?.addSubview(self)
//
//    loader.startAnimating()
//
//    loader.bringSubview(toFront: (application.window?.rootViewController?.view)!)
//    // UIApplication.shared.beginIgnoringInteractionEvents()
//  }
//
//  /// Hide Indicator View with animation
//  func hide() {
//    self.removeFromSuperview()
//    loader.stopAnimating()
//
//    // if UIApplication.shared.isIgnoringInteractionEvents {
//    // UIApplication.shared.endIgnoringInteractionEvents()
//    // }
//  }


class Indicator
{
    private init() {}
    static var instance = Indicator()

    func showActivityIndicator(view: UIView)
    {
        var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        activityIndicator.backgroundColor = UIColor(red:0.16, green:0.17, blue:0.21, alpha:1)
        activityIndicator.layer.cornerRadius = 6
        activityIndicator.center = view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.whiteLarge
//        activityIndicator.tag = 1
        view.addSubview(activityIndicator)
        activityIndicator.startAnimating()
        UIApplication.shared.beginIgnoringInteractionEvents()
    }

    func hideActivityIndicator()
    {
        let activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
        activityIndicator.stopAnimating()
        activityIndicator.removeFromSuperview()
        UIApplication.shared.endIgnoringInteractionEvents()
    }
}
