//
//  Utils.swift
//  SafexPay
//
//  Created by Sandeep on 27/09/20.
//  Copyright © 2020 Antino Labs. All rights reserved.
//

import Foundation
import UIKit

func convertToDictionary(text: String) -> [String: Any]? {
    if let data = text.data(using: .utf8) {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
        } catch {
            print(error.localizedDescription)
        }
    }
    return nil
}

func convertToArrayDictionary(text: String) -> [[String: Any]]? {
    if let data = text.data(using: .utf8) {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]]
        } catch {
            print(error.localizedDescription)
        }
    }
    return nil
}

func jsonToString(json: [String:String]) -> String?{
    do {
        let data1 =  try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.prettyPrinted) // first of all convert json to the data
        let convertedString = String(data: data1, encoding: String.Encoding.utf8) // the data will be converted to the string
//        print(convertedString) // <-- here is ur string
        return convertedString
    } catch let myJSONError {
        print(myJSONError)
        return nil
    }
}

func jsonToAny(json: [String:Any]) -> String?{
    do {
        let data1 =  try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.prettyPrinted) // first of all convert json to the data
        let convertedString = String(data: data1, encoding: String.Encoding.utf8) // the data will be converted to the string
        return convertedString
    } catch let myJSONError {
        print(myJSONError)
        return nil
    }
    
}

fileprivate var aView: UIView?

extension UIViewController
{
    func showSpinner()
    {
        aView = UIView(frame: self.view.bounds)
        aView?.backgroundColor = UIColor(red:0.16, green:0.17, blue:0.21, alpha:0.5)
        
        let ai = UIActivityIndicatorView(style: .whiteLarge)
        
        ai.center = aView!.center
        ai.startAnimating()
        aView?.addSubview(ai)
        self.view.addSubview(aView!)
    }
    
    func removeSpinner()
    {
        aView?.removeFromSuperview()
        aView = nil
    }
}
