//
//  TestSafexPayIOS.h
//  TestSafexPayIOS
//
//  Created by Yash Jadhav on 03/08/21.
//

#import <Foundation/Foundation.h>

//! Project version number for TestSafexPayIOS.
FOUNDATION_EXPORT double TestSafexPayIOSVersionNumber;

//! Project version string for TestSafexPayIOS.
FOUNDATION_EXPORT const unsigned char TestSafexPayIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestSafexPayIOS/PublicHeader.h>


