//
//  CreditDebitCardType.swift
//  SafexPay
//
//  Created by Yash Jadhav on 23/07/21.
//  Copyright © 2021 Antino Labs. All rights reserved.
//

import Foundation
import UIKit

struct CreditDebitCardType: Codable
{
//    var id: String = UUID().uuidString
    var type: String
    var prefix: [Int]
    var length: Int
    var imageName: String
//    var images: UIImage
}

let homecreditCardTypes = [
    CreditDebitCardType(type: "VISA", prefix: [4], length: 16, imageName: "ic_visa"),
    CreditDebitCardType(type: "MASTER CARD", prefix: [51, 52, 53, 54, 55], length: 16, imageName: "ic_mastercard"),
    CreditDebitCardType(type: "AMERICAN EXPRESSCARD", prefix: [34, 37], length: 16, imageName: "ic_amex")
]
