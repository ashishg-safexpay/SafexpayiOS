//
//  MerchantDetails.swift
//  SafexPay
//
//  Created by Yash Jadhav on 28/07/21.
//  Copyright © 2021 Antino Labs. All rights reserved.
//

import Foundation

struct MerchantDetails: Codable
{
    let merchantBrandingDetails: String
    let errorDetails: MerchantErrorDetails

    enum CodingKeys: String, CodingKey {
        case merchantBrandingDetails
        case errorDetails = "error_details"
    }
}

// MARK: - ErrorDetails
struct MerchantErrorDetails: Codable
{
    let errorCode, errorMessage: String

    enum CodingKeys: String, CodingKey {
        case errorCode = "error_code"
        case errorMessage = "error_message"
    }
}

